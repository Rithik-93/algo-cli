Problem Name: "Regular Expression Matching"
Function Name: sum
Input Structure:
Input Field: str str1
Input Field: str str2
Output Structure:
Output Field: bool result