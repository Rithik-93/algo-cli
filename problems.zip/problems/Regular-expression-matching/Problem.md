## Regular Expression matching

Given an input string s and a pattern p, implement regular expression matching with support for '.' and '*' where:

'.' Matches any single character.​​​​
'*' Matches zero or more of the preceding element.
The matching should cover the entire input string (not partial).

#### Test case 1

Input

```
s = "aa" 
p = "a"
```

Output

```
false
```

#### Test case 2

Input

```
s = "aa" 
p = "a*"
```

Output

```
true
```
