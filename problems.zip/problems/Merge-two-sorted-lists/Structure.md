Problem Name: "Merge two sorted lists"
Function Name: sum
Input Structure:
Input Field: list<int> arr1
Input Field: list<int> arr2
Output Structure:
Output Field: list<int> result
