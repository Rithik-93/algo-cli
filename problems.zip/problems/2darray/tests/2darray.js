function generateTestCases() {
  const testCases = [];

  for (let i = 0; i < 50; i++) {
    const m = Math.floor(Math.random() * 50) + 1; // Number of customers
    const n = Math.floor(Math.random() * 100) + 1; // Number of banks
    const accounts = [];

    for (let j = 0; j < m; j++) {
      const customerAccounts = [];
      for (let k = 0; k < n; k++) {
        customerAccounts.push(Math.floor(Math.random() * 100) + 1); // Random amount between 1 and 100
      }
      accounts.push(customerAccounts);
    }

    const input = accounts;
    const output = Math.max(...accounts.map(customer => customer.reduce((sum, amount) => sum + amount, 0)));

    testCases.push({ input, output });
  }

  return testCases;
}

console.log(JSON.stringify(generateTestCases()));