function generateTestCases() {
    const testCases = [];

    // Basic test cases
    testCases.push({ input: [1, 2, 3, 4, 5], output: 5 });
    testCases.push({ input: [5, 4, 3, 2, 1], output: 5 });
    testCases.push({ input: [1], output: 1 });
    testCases.push({ input: [-1, -2, -3, -4, -5], output: -1 });
    testCases.push({ input: [0], output: 0 });

    // Test cases with repeated elements
    testCases.push({ input: [1, 1, 1, 1, 1], output: 1 });
    testCases.push({ input: [3, 3, 3, 3, 5, 3, 3], output: 5 });
    testCases.push({ input: [10, 10, 10, 10, 10, 9], output: 10 });

    // Test cases with negative and positive numbers
    testCases.push({ input: [-5, 0, 5, -10, 10], output: 10 });
    testCases.push({ input: [-100, 0, 100], output: 100 });
    testCases.push({ input: [-1, 0, 1], output: 1 });

    // Test cases with large numbers
    testCases.push({ input: [1000000, 999999, 1000001], output: 1000001 });
    testCases.push({ input: [-1000000, 999999, -1000001], output: 999999 });

    // Test cases with decimals
    testCases.push({ input: [1.1, 1.2, 1.3, 1.4, 1.5], output: 1.5 });
    testCases.push({ input: [-1.5, -1.4, -1.3, -1.2, -1.1], output: -1.1 });

    // Generate random test cases
    for (let i = 0; i < 35; i++) {
        const length = Math.floor(Math.random() * 100) + 1;
        const arr = [];
        let max = -Infinity;
        for (let j = 0; j < length; j++) {
            const num = Math.floor(Math.random() * 2000) - 1000;
            arr.push(num);
            max = Math.max(max, num);
        }
        testCases.push({ input: arr, output: max });
    }

    return testCases;
}

console.log(JSON.stringify(generateTestCases()));